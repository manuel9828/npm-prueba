module.exports = {
  singleQuote: true,
  semi: false,
  trailingComma: 'es5',
  endOfLine: 'lf',
  arrowParens: 'avoid',
}
